# FORMULAR Angaben der versicherten Person

Installation und andere Anleitungen sind weiter in dieser DokumentationsDatei. 

## 1. Zweck der Entwicklung

Da .pdf Dateien nicht editierbar sind,
diese Software Lösung ist entwickelt worden,
zum Formular im .pdf Format zu erstelllen,
und einfach mit den elektronischen Daten zu versehen.

![Preview_html.png](docs/images/Preview_html.png)



## 2. Und Zusatz

```
Un a Käs un a Brot.
```

A. Sensible private Daten, wenn auch FinanzDaten,
werden lokal auf eigenem Computer bearbeitet,
oder auf dem Computer von der ALV.

B. ProgrammKode ist überprüfbar geblieben,
nicht eingeschiffret.

C. Das Formular ist wie eine InetSeite entwickelt worden,
und somit kann einfacher in eine MultiBenutzer SPA umgewandelt werden.

D.1. DatenPacket im `.json` Format kann sehr einfach zusammengepackt ( mit den Archivern wie `zip`, `tar`, `rar`, `gzip`, `7zip` ),
eingeschiffert und an ALV elektronisch geschickt werden.

D.2. DateiGrösse vom DatenPacket im `.json` Format beträgt nur 7 KB ( ca. Sieben Tausend Zeichen ).

    Das `.json` Format wird bevorzugt seit langem für seine Eigenschaften:
    
        D.2.1. `.json` Dateien sind einfach zu editieren in einer beliebigen Text IDE.
        D.2.2. `.json` Dateien können sehr effizient archiviert werden, oft ca. 16% von der Grösse von der `.json` Datei.
        D.2.3. `.json` Daten sind einfach in eine DatenBank zu importieren.
            D.2.3.2. Seit mehr als 10 Jahren gibt es im Inet mehrere JSON DatenBanken.



## 3. Wie die Applikation nutzen. 

```
Die Voraussetzung sei, 
im Rahmen der PreInstallation und Konfiguration.
auf dem Computer auch der Docker und Docker Compose Plugin installiert worden sind.
```


1.1. In der Datei im .json Format Ihre Daten angeben. `data/formular_data.json`

Dazu koennen Sie eine `Text IDE` benutzen, oder einen IDE Plugin fuer `JSON Dateien`.

![data_json_text.png](docs/images/data_json_text.png)


1.2. Vom Kode im Brief vom `RAV` auf der ersten Seite, den Kode croppen mit dem Photo IDE wie `Adobe PhotoShop`.

1.3. Die Image Datei mit dem Kode im DateiSystem speichern unter: `images/code_formular.png` 

1.4. Bild mit Ihrer Unterschrift  speichern unter: `images/signature.png`

1.5. Im Browser vorschauen auf der lokalen BrowserSeite: `http://localhost:2233/Formular/powered_by_php_doc.php`



1.3. TerminalKommand aufrufen: `./command/genPdf.sh`

1.4. .pdf Doc anschauen im Browser: `http://localhost:2233/pdf_doc/Formular.pdf`









## 4. Installation

```
Die Installation braucht Kenntnisse im Docker,
und somit versprochen, 
kann auch eine Woche Arbeitszet brauchen,
um die dazugehörige Dokumentationen zu lesen, zu lernen und auszuprobieren.
```



### 4.1. Wenn MS Windows OS, erst WSL Installieren.

### 4.2. Docker und Docker Compose Plugin Installieren ( wenn MS Windows OS, dann in der OS in der WSL ).

### 4.3. Dockerisierte Services Aufbauen ( im Kontext des installierten Docker und im Ordner von der Formular Applikation ).

**Dockerisierte Services Erklärt**

1. **princexml**: Kommand Line Tool `Prince` zum shreiben `.pdf` Dateien von `.html` Seiten.

2. **php**: Antrieb fuer `PHP` ProgrammierSprache. Auf Option.

        Aus dem `.json` DatenPacket, PHP automatisiert das Ausfüllen von Feldern auf der .html Seite Formular.
    
    
        Warum auf Option:
        Daten fuer Formular Felder koennen auch ohne Automatisation in der .html Datei eingetippt werden.

        wenn Sie Datei flat_doc.html editieren,
        dann in stylen, www/Formular/css/formular__color_scheme__base.css
        Linie 38: --doc_name--month-and-year: "Dezember 2025";
        können Sie eine andere Periode eingeben,
        und die wird an allen Stellen im Formular gesetzt,
        wo dafür vorgesehen worden ist.

        mit PHP, css class "powered_by_php" wird gesetzt, 
        und die style setzen diese css Variabel nicht,
        sondern die Daten werden von der .json Datei übernommen.

        Ich schaue später, dass ich die Style schreibe, 
        so dass die anderen Daten für die TopZeilen auch via CSS3 Variabeln eingetragen werden.



3. **localhost**: Dockerisierter Service vom `Jaisocx` Sites Server. Entwickelt und im Eigentum von der Schweizer Firma.

    Schluesselwort **localhost** wird gleichzeitig gebraucht als service Name,
    und Adresse von der lokalen .html Seite Formular: `http://localhost:2233/Formular/`

    Schluesselwort **localhost** in den InetSeiten Adressen heisst immer die lokale InetSeite auf dem Computer,
    an dem Sie gerade tätig sind, und das war so vom OS Manufacturer einprogrammiert.



#### 4.3.1. Services eins nach dem anderen bauen.

#### 4.3.1.1. PrinceXML

Datei `docker/princexml/Dockerfile`
Linie 22
```
RUN curl -LO https://www.princexml.com/download/prince-15.4.1-alpine3.20-aarch64.tar.gz
```
Im DateiNamen `prince-15.4.1-alpine3.20-aarch64.tar.gz` **aarch64** steht fuer eine CPU Architektur.

Erst pruefen den Namen von der CPU Architektur, ob amd, x64, arm64.

Dann auf die Adresse navigieren

[https://www.princexml.com/download/](https://www.princexml.com/download/)


Weiter auf die Liste von Software Installations Pakete navigieren und den link kopieren,
der an CPU Architektur Namen und Alpine 3.20 Docker Image passt.

```bash

docker compose build princexml
```



#### 4.3.1.2. PHP

```bash

docker compose build php
```


#### 4.3.1.3. Sites Server

```bash

docker compose build localhost
```



#### 4.3.2. Services eins nach dem anderen starten.

#### 4.3.2.1. PrinceXML

```bash

docker compose up princexml -d
```



#### 4.3.2.2. PHP

```bash

docker compose up php -d
```



#### 4.3.2.3. Sites Server

```bash

docker compose up localhost -d
```





### 4.4. Installation Prüfen.

[http://localhost:2233/Formular/](http://localhost:2233/Formular/)





## 5. Struktur

![filesystem_view.png](docs/images/filesystem_view.png)


