<?php

// Loads HTML block rendering on top of every page like this:
//    Seite 1 von 4
  $path_template_page_numbers     = "/var/www/Formular/php/template/page_numbers.html";
  $template_page_numbers = file_get_contents( $path_template_page_numbers );

// Loads HTML block rendering on top of every page
//   the cellspan with data of the insured.
  $path_template_page_data_lables = "/var/www/Formular/php/template/page_data_lables.html";
  $raw_template_page_data_lables = file_get_contents( $path_template_page_data_lables );



// Loads JSON containing data for this Formular
  $path_formular_data = "/var/www/Formular/data/formular_data.json";
  $raw_formular_data = file_get_contents( $path_formular_data );
  $parsed_data = json_decode( $raw_formular_data, true );

  $DATA = $parsed_data;

?>