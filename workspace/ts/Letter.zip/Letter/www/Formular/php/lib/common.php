<?php

// the array with css classNames
//   set due to boolean values from the JSON data of the Formular
  $NY = [ "no", "yes" ];
  $GENDER = [
    "man" => "Herr",
    "woman" => "Frau"
  ];

  $BACKGROUND_SPACE = " ";
  $DASH = "-";
  $COMMA = ",";

// the function translates boolean value
//   to one of values in the array as in argument $inTranslatingArray
  function getYNbyBool( $inTranslatingArray, $inBoolVal ) {
    $retYN = $inBoolVal ? $inTranslatingArray[1] : $inTranslatingArray[0];

    return $retYN;
  }

  // Example
  // echo getYNbyBool( $NY, $formular_data["1."]["answer"] );


?>