<?php

  function renderTemplate ( $html, $data ) {
    $SYMBOL_PLACEHOLDER_START = "{{";
    $SYMBOL_PLACEHOLDER_FINISH = "}}";

    $arrayOfHtmlDelimiteredByPlaceholders = explode ( $SYMBOL_PLACEHOLDER_START, $html );
    $htmlBlocks = [];
    $placeholdersOffsets = [];

    foreach( $arrayOfHtmlDelimiteredByPlaceholders as $key => $placeholderBlock ) {
      $subarr = explode ( $SYMBOL_PLACEHOLDER_FINISH, $placeholderBlock );
      $lenSubarr = count ( $subarr );
      if ( $lenSubarr === 1 ) {
        $htmlBlocks[] = $placeholderBlock;

      } else if ( $lenSubarr === 2 ) {

        $placeholderExpression = $subarr[0];
        $escapedPlaceholderExpression = str_ireplace ( '$', '\$', $placeholderExpression );
        $escapedPlaceholderExpression = str_ireplace ( '"', '\"', $escapedPlaceholderExpression );
        $expToEval = "\$htmlBlocks[] = $placeholderExpression;";

        $htmlBlocks[] = eval( $expToEval );
        $htmlBlocks[] = $subarr[1];
      }
    }

    $renderedHtml = join ( " ", $htmlBlocks );

    return $renderedHtml;
  }

?>