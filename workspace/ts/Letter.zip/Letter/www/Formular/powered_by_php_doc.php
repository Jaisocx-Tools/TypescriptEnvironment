<?php

  require_once ( "/var/www/Formular/php/lib/common.php" );
  require_once ( "/var/www/Formular/php/lib/render_template.php" );
  require_once ( "/var/www/Formular/php/main.php" );

  $template_page_data_lables = renderTemplate ( $raw_template_page_data_lables, $parsed_data );

?>
<!DOCTYPE html>
<html lang="en" class="jsx formular powered_by_php">
<head>
    <meta charset="UTF-8">
    <title> AVP </title>

    <link
        rel="icon"
        type="image/x-icon"
        href="favicon/alv_favicon.ico"
    />

<!--    <link-->
<!--        rel="icon"-->
<!--        type="image/x-icon"-->
<!--        href="favicon/jaisocx_favicon.ico"-->
<!--    />-->

    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="../fonts/fonts.css"
    />

    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="node_modules/@jaisocx/media_tools_fonts_base/MediaAndStyles/JscFonts_main_resolved.css"
    />

    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="node_modules/@jaisocx/css-clean-start-2/MediaAndStyles/CssCleanStart_2_main_resolved.css"
    />


    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="css/media_princexml.css"
    />

    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="css/media_screen_formular.css"
    />

    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="css/formular__color_scheme__base.css"
    />

    <link
        rel="stylesheet"
        type="text/css"
        charset="utf-8"
        href="css/zh.css"
    />



</head>
<body>
    <main>

<!--      NEW PAGE-->
      <?php
        echo $template_page_numbers;
        echo $template_page_data_lables;
      ?>



      <layout-block class="page_01_block__top">

        <layout-block class="doc_name powered_by_php">
          <lable> Angaben der versicherten Person für den Monat </lable>
          <data>
            <?php
            $period_paid = $DATA["data"]["period_paid"];
            $data = join (
              "",
              [
                $period_paid["month"],
                $BACKGROUND_SPACE,
                $period_paid["year"]
              ]
            );
            echo $data;
            ?>
          </data>
        </layout-block>

      </layout-block>



      <layout-block class="page_01_block_12__alv_insured_data">

<!--        <layout-block class="code_insured_data">-->
<!--          TYDAA-->
<!--        </layout-block>-->

        <layout-block class="address_of_alv">
          <lable> P.P. </lable>
          <address>
            RAV, Althardstrasse 10, CH-8105 Regensdorf
          </address>
        </layout-block>

        <layout-block class="address_of_insured">
          <line>
            <?php
            $insured = $DATA["data"]["insured"];

            $data = join (
              "",
              [
                $GENDER[ $insured["gender"] ],
                $BACKGROUND_SPACE,
                $insured["first_name"],
                $BACKGROUND_SPACE,
                $insured["family_name"]
              ]
            );
            echo $data;
            ?>
          </line>
          <line>
            <?php
            $insured_postal_address = $DATA["data"]["insured"]["postal_address"];
            $data = join (
              "",
              [
                $insured_postal_address["street_name"],
                $BACKGROUND_SPACE,
                $insured_postal_address["house_number"]
              ]
            );
            echo $data;
            ?>
          </line>
          <line>
            <?php
            $insured_postal_address = $DATA["data"]["insured"]["postal_address"];
            $data = join (
              "",
              [
                $insured_postal_address["country_code"],
                $DASH,
                $insured_postal_address["zip"],
                $BACKGROUND_SPACE,
                $insured_postal_address["town"]
              ]
            );
            echo $data;
            ?>
          </line>
        </layout-block>

        <layout-block class="data_of_insured">

          <data-cell data-name="kasse_number">
            <lable>
              ALV Kasse Nr.
            </lable>
            <value>
              <?php echo $DATA["data"]["insurance_company"]["number_company"]; ?>
            </value>
          </data-cell>

          <data-cell data-name="number_2">
            <lable>
              Zahlstelle Nr.
            </lable>
            <value>
              <?php echo $DATA["data"]["insurance_company"]["zahlstelle"]; ?>
            </value>
          </data-cell>

          <data-cell data-name="ihv_number_of_insured">
            <lable>
              AHVID
            </lable>
            <value>
              <?php echo $DATA["data"]["insured"]["ahv_number"]; ?>
            </value>
          </data-cell>

          <data-cell data-name="birth_date_of_insured">
            <lable>
              Geburtsdatum
            </lable>
            <value>
              <?php echo $DATA["data"]["insured"]["birth_date"]; ?>
            </value>
          </data-cell>

          <data-cell data-name="phone_number_of_insured">
            <lable>
              Mobile
            </lable>
            <value>
              <?php echo $DATA["data"]["insured"]["mobile"]; ?>
            </value>
          </data-cell>

        </layout-block>

      </layout-block>



      <layout-block class="page_01_block_13__notice">
        <p>
          Bitte beantworten Sie die Fragen auf der Rückseite. Die Fragen betreffen nur diesen Monat.
        </p>
      </layout-block>



      <layout-block class="page_01_block_14__notice">

        <p>
          Falls das Formular nicht vollständig ausgefüllt ist oder Beilagen fehlen, kann die Kasse keine Auszahlung
          vornehmen.
        </p>

        <p>
          Der Anspruch auf Versicherungsleistungen erlischt, wenn er nicht innert drei Monaten nach dem Ende der
          Kontrollperiode, auf die er sich bezieht, geltend gemacht wird.
        </p>

        <p>
          Melden Sie Ihrer Kasse unbedingt jede Arbeit, die Sie während des Bezugs von
          Arbeitslosenentschädigung ausführen. Ein Versicherungsbetrug lohnt sich nicht. Die Zentrale
          Ausgleichsstelle (AHV) informiert die Arbeitslosenversicherung über Arbeitsverhältnisse während der
          Arbeitslosigkeit.
        </p>

        <p>
          Unwahre oder unvollständige Angaben können zum Leistungsentzug und zu einer Strafanzeige führen. Zu
          Unrecht bezogene Leistungen müssen zurückbezahlt werden.
        </p>

      </layout-block>



      <layout-block class="page_01_block_17__code_img">

        <img class="code_formular" src="/Formular/images/code_formular.png" />
        <img class="signature" src="/Formular/images/signature.png" />

        <text class="signature__town_and_date">
          <?php
            $period_paid = $DATA["data"]["signature"];
            $data = join (
              "",
              [
                $period_paid["signed_place"],
                $COMMA,
                $BACKGROUND_SPACE,
                $period_paid["signed_date"]
              ]
            );
            echo $data;
            ?>
          </text>

      </layout-block>







<!--      NEW PAGE-->
      <?php
        echo $template_page_numbers;
        echo $template_page_data_lables;
      ?>





      <layout-block class="page_02_block_22__multiple_choice">

        <layout-block class="block_multiple_choice">

          <label>
            <question> 1. Haben Sie bei einem oder mehreren Arbeitgebern gearbeitet? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["1."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>

          </label>



          <delimiter></delimiter>

          <text> Falls ja, </text>

          <layout-block class="group_blocks_question">

            <block-question>
              <question>
                Arbeitgeber
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["1."]["answer_condition"]["0"]["employer"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Start
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["1."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Abschluss
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["1."]["answer_condition"]["0"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>

          <delimiter></delimiter>


          <layout-block class="group_blocks_question">

            <block-question>
              <question>
                Arbeitgeber
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["1."]["answer_condition"]["1"]["employer"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Start
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["1."]["answer_condition"]["1"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Abschluss
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["1."]["answer_condition"]["1"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>



          <notice>
            (bitte Bescheinigung(en) über Zwischenverdienst und Lohnabrechnung(e) beilegen)
          </notice>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 2. Haben Sie eine selbständige Erwerbstätigkeit ausgeübt? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["2."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>

          </label>



          <delimiter></delimiter>


          <layout-block class="group_blocks_question">

            <text>Falls ja,</text>

            <block-question class="short">
              <question>
                Start
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["2."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Abschluss
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["2."]["answer_condition"]["0"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>


          <notice>
            (bitte Belege/Abrechnungen beilegen)
          </notice>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 3. Haben Sie an einer arbeitsmarktlichen Massnahme teilgenommen? (z.B. Kurs, Programm zur
              vorübergehenden Beschäftigung, Praktikum)
            </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["3."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 4. Waren Sie arbeitsunfähig? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["4."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>


          <delimiter></delimiter>

          <layout-block class="group_blocks_question">
            <block-question>
              <question>
                Meldung am
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Meldung"]["am"]; ?>
              </answer>
            </block-question>


            <block-question class="short">
              <question>
                an
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Meldung"]["an"]; ?>
              </answer>
            </block-question>
          </layout-block>



          <delimiter></delimiter>

          <layout-block class="group_blocks_question">

            <text>Wegen Krankheit:</text>

            <block-question class="short">
              <question>
                Von
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Wegen Krankheit"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Ende
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Wegen Krankheit"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>
          <notice>(bitte Arztzeugnisse beilegen)</notice>



          <delimiter></delimiter>

          <layout-block class="group_blocks_question">

            <text>Wegen Unfall</text>

            <block-question class="short">
              <question>
                Von
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Wegen Unfall"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Ende
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Wegen Unfall"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>

          <notice>(bitte Arztzeugnisse beilegen)</notice>



          <delimiter></delimiter>

          <text>Aus anderen Gründen?</text>

          <layout-block class="group_blocks_question">

            <block-question>
              <question>
                Welche?
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Aus anderen Gründen?"]["reason"]; ?>
              </answer>
            </block-question>
          </layout-block>

          <layout-block class="group_blocks_question">

            <block-question class="short">
              <question>
                Von
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Aus anderen Gründen?"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Ende
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["4."]["answer_condition"]["Aus anderen Gründen?"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>



          <delimiter></delimiter>

          <label>
            <question> Haben Sie eine Taggeldversicherung für den Krankheitsfall? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["4.2."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 5a. Haben Sie Militär- oder Zivildienst, resp. Zivilschutz geleistet? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["5a."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>



          <layout-block class="group_blocks_question">

            <text>Falls ja,</text>

            <block-question class="short">
              <question>
                Von
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["5a."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Ende
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["5a."]["answer_condition"]["0"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>



          <label>
            <question> 5b. Haben Sie Mutterschafts- oder Vaterschaftsurlaub bezogen? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["5b."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>




          <layout-block class="group_blocks_question">

            <text>Falls ja,</text>

            <block-question class="short">
              <question>
                Start
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["5b."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Finish
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["5b."]["answer_condition"]["0"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>

        </layout-block>



      </layout-block>




<!--      NEW PAGE-->
      <?php
        echo $template_page_numbers;
        echo $template_page_data_lables;
      ?>



      <layout-block class="page_02_block_22__multiple_choice">

        <layout-block class="block_multiple_choice">

          <label>
            <question> 6a. Waren Sie in den Ferien? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["6a."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>



          <layout-block class="group_blocks_question">

            <text>Falls ja,</text>

            <block-question class="short">
              <question>
                Start
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["6a."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Finish
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["6a."]["answer_condition"]["0"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>



          <label>
            <question> 6b. Waren Sie aus anderen Gründen abwesend? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["6b."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>





          <layout-block class="group_blocks_question">

            <text>Falls ja,</text>
          <block-question>
            <question>
              Warum?
            </question>
            <answer>
              <?php echo $DATA["data"]["formular"]["6b."]["answer_condition"]["0"]["why"]; ?>
            </answer>
          </block-question>

          </layout-block>



          <layout-block class="group_blocks_question">

            <block-question class="short">
              <question>
                Start
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["6b."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                Ende
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["6b."]["answer_condition"]["0"]["end_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 7a. Hat sich Ihre Unterhaltspflicht oder diejenige Ihres Ehegatten/Ihrer Ehegattin oder Ihres/Ihrer
              eingetragenen Partners/Partnerin gegenüber Kindern unter 18 Jahren oder Kindern in Ausbildung verändert?
            </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["7a."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>

          <notice> (Falls ja, bitte Geburtsschein, Lehrvertrag, Bestätigung der Ausbildungsstätte und/oder Abschlussdiplom beilegen) </notice>



          <label>
            <question> 7b. Hat eine andere Person (z.B. anderer Elternteil) Anspruch auf Kinder- und/oder Ausbildungszulagen? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["7b."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>

          <notice> (Falls ja, bitte Geburtsschein, Lehrvertrag, Bestätigung der Ausbildungsstätte beilegen) </notice>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 8. Haben Sie Leistungen einer anderen in- oder ausländischen Sozialversicherung verlangt oder
              erhalten (z.B. Krankentaggeld, IV, SUVA, berufliche Vorsorge, AHVRentenvorbezug, EO)
            </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["8."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>


          <notice> (Falls ja, bitte Kopie der Verfügung und der Abrechnung beilegen) </notice>

        </layout-block>



        <layout-block class="block_multiple_choice">

          <label>
            <question> 9. Suchen Sie im gleichen Umfang (%) Arbeit wie im Vormonat? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["9."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>



          <text>Falls nein, </text>

          <layout-block class="group_blocks_question">
            <block-question>

              <question>
                in welchem Umfang suchen Sie insgesamt Arbeit?
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["9."]["answer_condition"]["0"]["work_time_percentage"]; ?>
              </answer>
            </block-question>

            <block-question class="short">
              <question>
                ab wann?
              </question>
              <answer>
                <?php echo $DATA["data"]["formular"]["9."]["answer_condition"]["0"]["start_freetext"]; ?>
              </answer>
            </block-question>

          </layout-block>

        </layout-block>

      </layout-block>



<!--      NEW PAGE-->
<!--
      <#php
        // echo $template_page_numbers;
        // echo $template_page_data_lables;
      #>
-->


      <layout-block class="page_02_block_22__multiple_choice">






        <layout-block class="block_multiple_choice">

          <label>
            <question> 10. Sind Sie weiterhin arbeitslos? </question>

            <block-yes-no class="<? echo getYNbyBool( $NY, $DATA["data"]["formular"]["10."]["answer"] ); ?>">
              <choice> Yes </choice>
              <choice> No </choice>
            </block-yes-no>
          </label>



          <layout-block class="group_blocks_question">

            <text>Arbeitsaufnahme</text>

          <block-question class="short">

            <question>
              am
            </question>
            <answer>
              <?php echo $DATA["data"]["formular"]["10."]["answer_condition"]["0"]["start_freetext"]; ?>
            </answer>
          </block-question>

          </layout-block>

        </layout-block>

      </layout-block>



      <layout-block class="page_02_block_23__notice">
        <block-question>
          <question> Bemerkungen: </question>
          <answer class="multiline">
            <?php echo $DATA["data"]["formular"]["Bemerkungen"]["answer"]; ?>
          </answer>
        </block-question>
      </layout-block>

    </main>
</body>
</html>


