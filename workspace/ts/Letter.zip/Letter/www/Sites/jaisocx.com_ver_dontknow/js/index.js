const JAISOCX_DOWNLOAD_URL = '/download-current';
const URLS = {
    'download-http': '/download-http',
    'download-http-sql': '/download-http-sql',
};

function contactFormSend() {

    console.log(formElementsIds);

    popupMessageSentOpen();
}

function donationButtonsAssignEvents() {
    const donationButtonsCollection = document.querySelectorAll('.donation-buttons .donation-btn');

    for (let button of donationButtonsCollection) {
        button.addEventListener('click', (evt) => {
            donationButtonActivateOnClick(evt);
        });
    }
}

function donationButtonActivate(button) {
    const activeButton = document.querySelector('.donation-buttons .donation-btn.active');
    if (activeButton) {
        activeButton.classList.remove('active');
        activeButton.classList.add('default');
    }

    button.classList.remove('default');
    button.classList.add('active');

    const donationUrl = button.dataset.link;
    const donationsAnchor = document.getElementById('donation-anchor');
    donationsAnchor.href = donationUrl;
}

function donationButtonActivateOnload() {
    const button = document.querySelector('.donation-buttons .donation-btn.active');
    donationButtonActivate(button);
}

function donationButtonActivateOnClick(evt) {
    const clickEventTarget = evt.target;
    const button = clickEventTarget.closest('.donation-btn');

    donationButtonActivate(button);
}

function popupOpen(selector) {
    const mainContainer = document.querySelector('.main_popup_container');
    const popup = document.querySelector(selector);
    mainContainer.classList.remove('popup_container-disable');
    popup.classList.remove('popup-disable');
    document.body.style.overflowY = 'hidden';
}
function popupClose(selector) {
    const mainContainer = document.querySelector('.main_popup_container');
    const popup = document.querySelector(selector);
    mainContainer.classList.add('popup_container-disable');
    popup.classList.add('popup-disable');
    document.body.style.overflowY = 'auto';
}
function popupMessageSentOpen() {
    popupOpen('.popup-message-sent');
}
function popupMessageSentClose() {
    popupClose('.popup-message-sent');
}
function popupDownloadOpen() {
    popupOpen('.popup-terms');
}
function popupDownloadClose() {
    popupClose('.popup-terms');
}

function popupDownloadInit() {
    const popupOpenButton = document.getElementById('download-button');
    popupOpenButton.addEventListener('click', () => {
        popupDownloadOpen();
    });

    const btnClose = document.querySelector('.popup-terms .btn-popup-close');
    btnClose.addEventListener('click', () => {
        popupDownloadClose();
    });

    const checkboxes = document.querySelectorAll('.popup-terms input[type="checkbox"]');
    for (let checkbox of checkboxes) {
        checkbox.addEventListener('change', () => {
            allowDownload(checkboxes);
        });
    }
}

function allowDownload(checkboxes) {
    let allow = true;
    for (let checkbox of checkboxes) {
        if (!checkbox.checked) {
            allow = false;
            break;
        }
    }
    const downloadBtns = document.querySelectorAll('.popup-terms .btn-popup-download');
    for (let button of downloadBtns) {
        if (allow) {
            button.classList.remove('disabled');
            button.classList.add('active');
            button.addEventListener('click', registerDownloadAction);
            button.href = URLS[button.id];
            //button.target = '_blank';
        } else {
            button.classList.remove('active');
            button.classList.add('disabled');
            button.href = 'javascript: void(0);';
            button.removeEventListener('click', registerDownloadAction);
            button.target = '_self';
        }
    }
}

function burgerKingInit() {
    let menuBtn = document.querySelector('.menu-btn');
    let navBtns = document.querySelectorAll('.nav-btn')
    let menu = document.querySelector('.menu');
    menuBtn.addEventListener('click', function(){
        menu.classList.toggle('menu-active');
        menuBtn.classList.toggle('menu-btn-active')
    });

    for (const navBtn of navBtns) {
        navBtn.addEventListener('click', function(){
            menu.classList.remove('menu-active');
            menuBtn.classList.remove('menu-btn-active')
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {

    try {
        donationButtonsAssignEvents();
    } catch (e) {}
    try {
        popupDownloadInit();
    } catch (e) {}
    try {
        donationButtonActivateOnload();
    } catch (e) {}

    //popupDownloadOpen();
});
