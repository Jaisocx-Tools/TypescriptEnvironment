#!/usr/bin/env bash

gen_pdf() {

  local letter_name="$1"
  local owner_pwd="$2"
  local html_doc="$3"

  prince --media=print-for-screen "http://localhost:2233/${letter_name}/${html_doc}" \
      -o "/var/pdf_doc/${letter_name}.pdf" \
      --pdf-title "${letter_name}" \
      --pdf-subject "${letter_name}" \
      --pdf-author "ILLIA POLIANSKYI" \
      --pdf-creator "ILLIA POLIANSKYI" \
      --encrypt \
      --owner-password "${owner_pwd}" \
      --page-margin 3mm
}


