#!/usr/bin/env bash

. "./command/.env"

script_sources="$(cat "./command/func_gen_pdf.sh")"

script_sources="
${script_sources}

gen_pdf \"${letter_name}\" \"${owner_pwd}\" \"${letter_doc}\""



docker compose exec princexml bash -c "${script_sources}"

echo -e "\n$:_DONE\n\n"


